const {createReceptSchema, updateReceptSchema} = require('../schemas/recepty');
const ExpressError = require('../utils/ExpressError');
const Joi = require('joi');

module.exports.validateRecept = (req,res,next) => {
    let schemaToUse;
    if(req.method === 'POST'){
        schemaToUse = createReceptSchema;
    }else if(req.method === 'PATCH'){
        schemaToUse = updateReceptSchema;
    }
    console.log(req.body.recept);
    const {error, value } = schemaToUse.validate(req.body);
    if(error){
        const message = error.details.map((el) => el.message).join(',');
        throw new ExpressError(message,400);
    }else{ 
        req.validatedRecept = value.recept;
        next();
    }
};