module.exports = (functionToBeWrapped) => {
    const wrappinngFunction = (req,res,next) => {
        functionToBeWrapped(req,res,next).catch(next);
    }
    return wrappinngFunction;
};