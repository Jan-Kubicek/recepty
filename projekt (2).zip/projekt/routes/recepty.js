const express = require("express");
const router = express.Router();
const receptyControllers = require("../controllers/recepty");
const catchAsync = require("../utils/catchAsync");
const {validateRecept} = require("../middleware/recepty-validation");
const upload = require("../middleware/upload");


router.route("/")
.get(catchAsync(receptyControllers.allRecepty))
.post(validateRecept,upload.single('recept[obrazek]'),catchAsync(receptyControllers.createRecept)) ;

router.get("/new",receptyControllers.renderNewRecept);

router.get("/showMy",receptyControllers.showMyRecepty);

router
  .route("/:id")
  .get(catchAsync(receptyControllers.showRecept))
  .patch(validateRecept,catchAsync(receptyControllers.updateRecept))
  .delete(catchAsync(receptyControllers.deleteRecept));

  router.get("/:id/edit",catchAsync(receptyControllers.renderEditRecept));

module.exports = router;