const Recept = require('../models/recepty');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const ExpressError = require('../utils/ExpressError')

// Konfigurace multer pro nahrávání souborů
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Cílová složka pro ukládání souborů
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)); // Název souboru
    }
});

// Filtr pro povolení pouze určitých typů souborů
const fileFilter = function (req, file, cb) {
    if (
        file.mimetype === "image/jpeg" ||
        file.mimetype === "image/jpg"  ||
        file.mimetype === "image/png"
    ) {
        cb(null, true);
    } else {
        cb(null, false);
    }
};

// Inicializace multer s konfigurací
const upload = multer({ storage: storage, fileFilter: fileFilter });

module.exports.allRecepty = async (req, res) => {
    const recepty = await Recept.find({})
    res.render("index", {recepty})
}
// Funkce pro vytváření receptu
module.exports.createRecept = async (req, res) => {
    console.log(req.body.recept);
    console.log(req.validatedRecept);
   const{title, zdroj, text, viditelnost} = req.validatedRecept;
   const username = "Jan_Kubicek";
    const pathToImage = req.file.path;
    const base64Image = fs.readFileSync(pathToImage, { encoding: 'base64' });
    const buffer = Buffer.from(base64Image, 'base64');
    const recept = new Recept({
        username:username, title:title, picture:buffer , zdroj: zdroj, text: text, viditelnost: viditelnost
   })

   await recept.save();

   res.redirect("/recepty");
};

module.exports.renderNewRecept = (req, res) =>{
    res.render("vytvoreniReceptu")
}
module.exports.showRecept = async(req,res) => {
    const {id} = req.params;
    const recept = await Recept.findById(id);
    if(!recept){
        throw new ExpressError("Document not found",404)
      }
    res.render("receptDetaily", {recept});
}
module.exports.updateRecept = async (req,res) =>{
    const {id} = req.params;
    const { title, zdroj, text, viditelnost } = req.validatedRecept;
    const updatedRecept = await Recept.findByIdAndUpdate(id,{ title:title, picture:buffer , zdroj: zdroj, text: text, viditelnost: viditelnost})
    if(!updatedRecept){
        throw new ExpressError("Document not found",404)
      }
    res.redirect("/recepty")
}
module.exports.deleteRecept = async (req,res) =>{
    const {id} = req.params;
    const deletedRecept = await Recept.findByIdAndDelete(id)
    if(!deletedRecept){
        throw new ExpressError("Document not found",404)
    }
    res.redirect("/recepty");
}

module.exports.renderEditRecept = async (req, res) =>{
    const{id} = req.params;
    const recept = await Recept.findById(id);
    if(!recept){
        throw new ExpressError("Document not found",404)
      }
    res.render("upravaReceptu", {recept})
}

module.exports.showMyRecepty = async(req,res) => {
    const receptyAll = await Recept.find({})
    const receptyMy = receptyAll.filter((recept) => recept.username === "Jan_Kubicek")
    if(!receptyMy){
        throw new ExpressError("Document not found",404)
    }
    res.render("mojeRecepty",{receptyMy})
}
module.exports.pageDoesNotExists = (req,res) =>{
    res.render("strankaNeexistuje")
}