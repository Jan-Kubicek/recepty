const Joi = require('joi');

module.exports.createReceptSchema = Joi.object({
    recept: Joi.object({
        title: Joi.string().required(),
        picture: Joi.binary().required(), // Upraveno na přijetí obrázku jako Buffer
        zdroj: Joi.string().required(),
        text: Joi.string().required(),
        viditelnost: Joi.number().required(),
    }),
});

module.exports.updateReceptSchema = Joi.object({
    recept: Joi.object({
        title: Joi.string().required(),
        picture: Joi.binary().required(), // Upraveno na přijetí obrázku jako Buffer
        zdroj: Joi.string().required(),
        text: Joi.string().required(),
        viditelnost: Joi.number().required(),
    })
});