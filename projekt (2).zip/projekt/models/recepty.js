const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ReceptSchema = new Schema({
    username:{
        type:String,
        required:true,
    },
    title:{
        type:String,
        required:true
    },
    zdroj:{
        type:String,
        required:true
    },
    text:{
        type:String,
        required:true
    },
    picture:{
        type:Buffer,
        required:true
    },
    viditelnost:{
        type:Number,
        required:true
    }
});
ReceptSchema.post('save',(error, doc, next) => {
    if(error.name === "ValidationError"){
        const validationErrors = Object.values(error.errors).map((err) => err.message);
        next(new Error(validationErrors.join(',')));  
    }else{
        next(error);
    }
});
module.exports = mongoose.model("Recept",ReceptSchema);