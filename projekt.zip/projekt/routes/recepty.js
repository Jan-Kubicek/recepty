const express = require("express");
const router = express.Router();
const receptyControllers = require("../controllers/recepty");

const upload = require('../controllers/recepty').upload

router.route("/")
.get(receptyControllers.allRecepty)
.post(upload.single('obrazek'),receptyControllers.createRecept) 

router.get("/new",receptyControllers.renderNewRecept)

router.get("/showMy",receptyControllers.showMyRecepty)

router.get("/:id/edit",receptyControllers.renderEditRecept)

router
  .route("/:id")
  .get(receptyControllers.showRecept)
  .patch(receptyControllers.updateRecept)
  .delete(receptyControllers.deleteRecept);

module.exports = router