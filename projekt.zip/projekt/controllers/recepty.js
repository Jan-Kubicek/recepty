const Recept = require("../models/recepty");
const multer = require('multer');
const fs = require('fs').promises;
const path = require('path');

// Konfigurace multer pro nahrávání souborů
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Cílová složka pro ukládání souborů
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)); // Název souboru
    }
});

// Filtr pro povolení pouze určitých typů souborů
const fileFilter = function (req, file, cb) {
    if (
        file.mimetype === "image/jpeg" ||
        file.mimetype === "image/jpg"  ||
        file.mimetype === "image/png"
    ) {
        cb(null, true);
    } else {
        cb(null, false);
    }
};

// Inicializace multer s konfigurací
const upload = multer({ storage: storage, fileFilter: fileFilter });

module.exports.allRecepty = async (req, res) => {
    const recepty = await Recept.find({})
    res.render("index", {recepty})
}
// Funkce pro vytváření receptu
module.exports.createRecept = async (req, res) => {
   const{title, zdroj, text} = req.body;
   const username = "Jan_Kubicek";

    const recept = new Recept({
        username, title, picture:req.body.obrazek , zdroj, text
   })

   await recept.save();

   res.redirect("/recepty");
};
/*
 try {
        const { title, zdroj, text } = req.body;
        const username = "Jan_Kubicek";

        // Zkontrolujte, zda je req.file definován a obsahuje cestu k obrázku
        if (!req.file) {
            throw new Error('Není nahrán žádný obrázek.');
        }

        // Přečtěte obrázek asynchronně
        const imageData = await fs.readFile(req.file.path);

        // Vytvoření nové instance receptu
        const recept = new Recept({
            username,
            title,
            picture: {
                data: imageData,
                contentType: req.file.mimetype
            }, // Uložení obrázku do objektu s daty a typem obsahu
            zdroj,
            text
        });

        // Uložení receptu do databáze
        await recept.save();

        // Smazání dočasně uloženého obrázku
        await fs.unlink(req.file.path);

        // Přesměrování na stránku receptů
        res.redirect("/recepty");
    } catch (error) {
        console.error("Chyba při ukládání receptu:", error);
        res.status(500).send("Chyba při ukládání receptu");
    }
*/
module.exports.renderNewRecept = (req, res) =>{
    res.render("vytvoreniReceptu")
}
module.exports.showRecept = async(req,res) => {
    const {id} = req.params;
    const recept = await Recept.findById(id);
    res.render("receptDetaily", {recept});
}
module.exports.updateRecept = async (req,res) =>{
    const {id} = req.params;
    const { title, picture , zdroj, text, viditelnost } = req.body;
    await Recept.findByIdAndUpdate(id,{text: text,title: title,zdroj: zdroj})
    res.redirect("/recepty")
}
module.exports.deleteRecept = async (req,res) =>{
    const {id} = req.params;
    await Recept.findByIdAndDelete(id)
    res.redirect("/recepty");
}

module.exports.renderEditRecept = async (req, res) =>{
    const{id} = req.params;
    const recept = await Recept.findById(id);
    res.render("upravaReceptu", {recept})
}

module.exports.showMyRecepty = async(req,res) => {
    const receptyAll = await Recept.find({})
    const receptyMy = receptyAll.filter((recept) => recept.username === "Jan_Kubicek")
    res.render("mojeRecepty",{receptyMy})
}
module.exports.pageDoesNotExists = (req,res) =>{
    res.render("strankaNeexistuje")
}