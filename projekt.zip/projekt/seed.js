const mongoose = require("mongoose")
const Recept = require("./models/recepty")
const fs = require('fs')
const path = require('path')

let recepty = [
    {
      username: "Jan_Kubicek",
      title:"Kyjevský řízek s brokolicovou kaší",
      zdroj:"https://www.recepty.cz/recept/kyjevsky-rizek-s-brokolicovou-kasi-164614",
      text: "Nejprve připravte máslo. Nasekejte česnek a bylinky na velmi jemno a spolu s chilli a citronovou kůrou zatřete do másla. Máslo vytvarujte do hranolu a nechte ztuhnout, nejlépe v mrazáku. Maso očistěte, osolte a opepřete. Ostrým tenkým nožem v něm ze strany vytvořte velkou kapsu. Ochucené máslo pokrájejte na čtvrtiny a každou vložte do jedné kapsy. Prsa obtočte slaninou, abyste kapsy uzavřeli. Řízek obalte nejprve v mouce, poté v rozšlehaném osoleném a opepřeném vejci a nakonec ve strouhance. Troubu rozehřejte na 180 °C. Na pánvi rozpalte olej a řízky na něm opékejte 6 minut z každé strany. Poté je 10 minut dopečte v troubě. Mezitím uvařte oloupané a na kostky nakrájené brambory, asi 15 minut. Brokolici rozeberte na růžičky, vsypte ji do osolené vroucí vody a vařte 5 minut. Slijte a rozmixujte. K uvařeným a slitým bramborám přidejte máslo a rozmačkejte je na hladkou kaši. Nakonec vmíchejte brokolici. Řízky servírujte s kaší a měsíčkem citronu.",
      picture:fs.readFileSync(path.join(__dirname,'/pictures/kyjevsky_rizek_s_brokolicovou_kasi.jpg'))
    },
    {
        username: "Jan_Kubicek",
        title:"Omeleta s čedarem",
        zdroj:"https://www.recepty.cz/recept/omeleta-s-cedarem-163992",
        text: "Na talíře rozdělte špenátové listy, očištěné a pokrájené ředkvičky a avokádo nakrájené na plátky. Čedar nastrouhejte nahrubo. Do misky rozklepněte 2 vejce a prošlehejte je vidličkou, přidejte 2 lžíce smetany a dobře promíchejte, směs osolte a opepřete. Na středně vyhřáté pánvi rozpusťte 1 lžíce másla a vlijte vaječnou směs. Postupně ji vařečkou nebo špachtlí hrňte směrem do středu a přelévejte na uvolněné místo na pánvi. Pracujte rychle, omeleta bude hotová během pár minut, povrch musí zůstat krémový. Zasypte ho částí nastrouhaného sýra, omeletu částečně srolujte a nechte sklouznout z pánve na talíř. Stejným způsobem připravte zbývající omelety. Na talíři je můžete ještě posypat zbylým sýrem. Zeleninu zakápněte olivovým olejem, osolte, opepřete a ihned podávejte.",
        picture: fs.readFileSync(path.join(__dirname,'/pictures/omeleta_s_cedarem.jpg'))
      },
      {
        username: "Petra_Jezkova",
        title:"Jihočeská kulajda podle časopisu",
        zdroj:"https://www.recepty.cz/recept/jihoceska-kulajda-podle-casopisu-f-o-o-d-167459",
        text: "Houby dejte do misky a zalijte je horkou vodou. Oloupejte brambory a nakrájejte je na kostičky. V rendlíku přiveďte k varu vodu, dejte do ní vejce a vařte 8 minut. Poté je zchlaďte v ledové vodě a oloupejte. V hrnci rozpusťte máslo, zaprašte ho moukou a umíchejte jíšku. Zalijte ji vývarem, přidejte vodu z hub a metličkou vše dobře rozmíchejte, aby se jíška rovnoměrně rozpustila. Přidejte brambory, houby a koření, přiveďte k varu a vařte na mírném plameni, dokud nejsou brambory takřka hotové. Vlijte smetanu, polévku ochuťte solí a pepřem, přidejte většinu nasekaného kopru. Už nevařte a chuť dolaďte cukrem a octem, dochucujte postupně podle toho, jak kyselou polévku máte rádi. Tu nalijte do talířů, přidejte vejce a zbylý kopr.",
        picture: fs.readFileSync(path.join(__dirname,'/pictures/jihoceska_kulajda.jpg'))
      },
      {
        username: "Petr_Kovac",
        title:"Citronový koláč dle časopisu",
        zdroj:"https://www.recepty.cz/recept/citronovy-kolac-dle-casopisu-f-o-o-d-156503",
        text: "Cukr, pudink a prášek do pečiva důkladně promíchejte v míse. Přidejte rozpuštěné máslo a šťávu vymačkanou z citronů (máte-li chemicky neošetřené, můžete použít i trochu nastrouhané kůry). Nakonec přidejte tvaroh a vajíčka a vše spojte, pro jemnější konzistenci můžete směs prošlehat ručním šlehačem.Dortovou formu vyložte zespodu papírem a boky vymažte a vysypejte moukou. Připravenou směs nalijte do formy, dejte do trouby vyhřáté na 180 °C a pečte asi 40 minut. Koláč nabude na objemu, ale nelekněte se, že po zchladnutí zase spadne. Z formy ho vyjměte až po vychladnutí a ozdobte krémem z ušlehané smetany, tvarohu a cukru a plátky citronu a limetky.",
        picture:fs.readFileSync(path.join(__dirname,'/pictures/citronovy_kolac.jpg'))
      },
      {
        username: "Petr_Kovac",
        title:"Mrkvová buchta",
        zdroj:"https://www.recepty.cz/recept/mrkvova-buchta-165302",
        text: "Vypracujte drobenku. Máslo rozdělte na menší kousky a přidejte všechny zbylé ingredience, pomocí rukou vytvořte drobenku. Troubu předehřejte na 175 °C a plech vyložte pečicím papírem. Mrkev nastrouhejte najemno. Smíchejte mandle, mouku, prášek do pečiva a skořici. V jiné míse vyšlehejte vejce s cukrem. Pak postupně zapracujte olej. Obě směsi smíchejte dohromady společně s nastrouhanou mrkví. Těsto vlijte do předem připravené formy a posypte drobenkou. Pečte do zezlátnutí, asi 35–40 minut.",
        picture: fs.readFileSync(path.join(__dirname,'/pictures/mrkvova_buchta.jpg'))
      },
      {
        username: "Martina_Balounova",
        title:"Jarní minestrone s petrželovým pestem",
        zdroj:"https://www.recepty.cz/recept/jarni-minestrone-s-petrzelovym-pestem-166309",
        text: "Připravte pesto. Do mixéru dejte petrželku, oloupaný a nasekaný česnek, zalijte olivovým olejem, osolte, opepřete a rozmixujte dohladka. Cibuli, mrkev, brambory a řapíkatý celer očistěte, cibuli nasekejte nadrobno, mrkev pokrájejte na kolečka, řapíkatý celer na plátky, brambory na malé kostičky. Cuketu také pokrájejte na kostičky. V hrnci na lžíci oleje nechte zpěnit cibuli s řapíkatým celerem. Restujte asi dvě minuty, vlijte vývar a přiveďte k varu. Přidejte mrkev a brambory a asi po pěti minutách cuketu, těstoviny a povolený hrášek. Polévku ochuťte solí a pepřem a opět přiveďte k varu. Vařte asi o dvě minuty méně, než je uvedeno na obalu těstovin. Těstoviny zůstanou v polévce a ještě změknou a nabudou. Polévku rozdělte do misek, do každé přidejte lžíci pesta a nastrouhaný parmazán. Podávejte ji s opečenou bagetou.",
        picture: fs.readFileSync(path.join(__dirname,'/pictures/jarni_minestrone_petrzelove_pesto.jpg'))
        
      },
  ]

  mongoose
  .connect("mongodb://127.0.0.1:27017/seznam-receptu")
  .catch((error) => console.log(error))

  const db = mongoose.connection
  db.once("open", () => console.log("Database connected"))

  const seedDB = async () => {
    await Recept.insertMany(recepty)
  }

  seedDB()
  .then(() => {
    mongoose.connection.close()
    console.log("Writing to DB successful, DB disconnected")
  })
  .catch((error) => {
    console.log("Error while writing to DB")
  })
