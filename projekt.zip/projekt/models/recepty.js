const mongoose = require("mongoose")
const Schema = mongoose.Schema

const ReceptSchema = new Schema({
    username:String,
    title:String,
    zdroj:String,
    text:String,
    picture:Buffer
})

module.exports = mongoose.model("Recept",ReceptSchema)