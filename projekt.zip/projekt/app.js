const express = require("express");
const path = require("path");
const methodOverride = require("method-override");
const mongoose = require("mongoose");
const receptyRouter = require("./routes/recepty")


mongoose
.connect("mongodb://127.0.0.1:27017/seznam-receptu")
.catch((error) => console.log(error))

const db = mongoose.connection
db.once("open", () => console.log("Database connected"))

const app = express();

app.use(express.urlencoded({extended: true}));
app.use(express.json());
app.use(methodOverride("_method"));
app.use("/recepty",receptyRouter);
app.use('/uploads',express.static('uploads'))

app.use(express.static(path.join(__dirname, 'styles')));
app.use(express.static(path.join(__dirname, 'pictures')));
app.use(express.static(path.join(__dirname, 'public')));


app.set("view engine","ejs");
app.set("views",path.join(__dirname,"/views"));

app.get("*",(req, res) =>{
    res.render("strankaNeexistuje")
});

app.listen(3000, () => { console.log("Web server is running and listening")});